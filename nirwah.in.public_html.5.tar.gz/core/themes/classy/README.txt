ABOUT CLASSY
-----------

Classy is a base theme that provides many classes in its markup. For cleaner
markup (fewer classes), the default Stable base theme can be used instead.

To use Classy as your base theme, set the 'base theme' in your theme's .info.yml
file to "classy":
  base theme: classy

See https://www.drupal.org/docs/8/theming-drupal-8/using-classy-as-a-base-theme
for more information on using the Classy theme.

ABOUT DRUPAL THEMING
--------------------

See https://www.drupal.org/docs/8/theming for more information on Drupal
theming.
